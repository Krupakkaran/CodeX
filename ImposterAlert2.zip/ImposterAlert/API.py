from re import template
from flask import Flask, request, jsonify
from regex import template  # noqa: F401
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification

app = Flask(__name__)

# Load the pre-trained model pipeline
pipe = pipeline("text-classification", model="FakeNewsLlama/SocialTrueFakeClassifier_C1_E1")

# Alternatively, load the model and tokenizer separately
tokenizer = AutoTokenizer.from_pretrained("FakeNewsLlama/SocialTrueFakeClassifier_C1_E1")
model = AutoModelForSequenceClassification.from_pretrained("FakeNewsLlama/SocialTrueFakeClassifier_C1_E1")

@app.route('/classify', methods=['POST'])
def classify_text():
    # Get text data from the frontend
    data = request.get_json()
    text = data['text']

    # Using the pipeline for classification
    result = pipe(text)

    # Using the model and tokenizer directly
    # Tokenize input text
    inputs = tokenizer(text, return_tensors="pt")

    # Perform inference
    outputs = model(**inputs)

    # Get the predicted label
    predicted_label = outputs.logits.argmax().item()
    predicted_class = pipe.model.config.id2label[predicted_label]

    return jsonify({"result": result, "predicted_class": predicted_class})
    

if __name__ == '_main_':
    app.run(debug=True)