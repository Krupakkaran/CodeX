from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification

# Load the pre-trained model pipeline
pipe = pipeline("text-classification", model="FakeNewsLlama/SocialTrueFakeClassifier_C1_E1")

# Alternatively, load the model and tokenizer separately
tokenizer = AutoTokenizer.from_pretrained("FakeNewsLlama/SocialTrueFakeClassifier_C1_E1")
model = AutoModelForSequenceClassification.from_pretrained("FakeNewsLlama/SocialTrueFakeClassifier_C1_E1")

# Sample text data for classification
text = "This is a sample text to test the fake social media profile detector."

# Using the pipeline for classification
result = pipe(text)

print(result)

# Using the model and tokenizer directly
# Tokenize input text
inputs = tokenizer(text, return_tensors="pt")

# Perform inference
outputs = model(**inputs)

# Get the predicted label
predicted_label = outputs.logits.argmax().item()
predicted_class = pipe.model.config.id2label[predicted_label]

print("Predicted class:", predicted_class)